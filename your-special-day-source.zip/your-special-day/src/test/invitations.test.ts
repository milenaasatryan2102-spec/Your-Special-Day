import { describe, expect, it } from "vitest";

import { formatYerevanDate, summarizeGuests, yerevanLocalToIso } from "@/lib/invitations";

describe("guest answers summary", () => {
  it("adds up how many people are coming and counts who declined", () => {
    const summary = summarizeGuests([
      { attending: true, guest_count: 2 },
      { attending: true, guest_count: 4 },
      { attending: false, guest_count: 0 },
    ]);
    expect(summary.totalGuests).toBe(6);
    expect(summary.comingAnswers).toBe(2);
    expect(summary.notComingAnswers).toBe(1);
  });
});

describe("invitation dates", () => {
  it("shows the time the couple entered, in Yerevan time", () => {
    expect(formatYerevanDate(yerevanLocalToIso("2027-09-20T16:00"))).toBe("20 սեպտեմբերի 2027, 16:00");
  });
});
