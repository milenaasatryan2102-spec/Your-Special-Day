import { describe, expect, it } from "vitest";

import { filterTemplates, formatPrice, priceOf, templates } from "@/lib/catalog";

describe("catalog pricing", () => {
  it("charges 8 900 ֏ for a standard invitation", () => {
    expect(formatPrice(priceOf({ animated: false }))).toBe("8 900 ֏");
  });

  it("charges 11 900 ֏ for an animated invitation", () => {
    expect(formatPrice(priceOf({ animated: true }))).toBe("11 900 ֏");
  });
});

describe("catalog filters", () => {
  it("shows only wedding invitations under the wedding category", () => {
    const result = filterTemplates(templates, { category: "wedding" });
    expect(result.length).toBeGreaterThan(0);
    expect(result.every((t) => t.category === "wedding")).toBe(true);
  });

  it("shows only animated invitations when the animated filter is on", () => {
    const result = filterTemplates(templates, { animated: true });
    expect(result.length).toBeGreaterThan(0);
    expect(result.every((t) => t.animated)).toBe(true);
    expect(result.length).toBeLessThan(templates.length);
  });
});
