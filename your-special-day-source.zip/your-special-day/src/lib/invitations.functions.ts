import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

import type { Database } from "@/integrations/supabase/types";

// Public client: guests have no account, so these calls go through narrow
// database functions that never expose the couple's private key.
function publicClient() {
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) throw new Error("Backend is not configured");
  return createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) {
          headers.delete("Authorization");
        }
        headers.set("apikey", key);
        return fetch(input, { ...init, headers });
      },
    },
  });
}

export type PublicEvent = {
  slug: string;
  templateSlug: string;
  eventType: string;
  title: string;
  eventDate: string;
  venue: string | null;
  address: string | null;
  mapUrl: string | null;
  message: string | null;
};

export const getPublicEvent = createServerFn({ method: "GET" })
  .inputValidator((input: { slug: string }) => z.object({ slug: z.string().min(1).max(80) }).parse(input))
  .handler(async ({ data }): Promise<PublicEvent | null> => {
    const { data: rows, error } = await publicClient().rpc("get_public_event", { _slug: data.slug });
    if (error) {
      console.error("get_public_event failed", error);
      throw new Error("Հրավիրատոմսը հնարավոր չեղավ բեռնել");
    }
    const row = rows?.[0];
    if (!row) return null;
    return {
      slug: row.slug,
      templateSlug: row.template_slug,
      eventType: row.event_type,
      title: row.title,
      eventDate: row.event_date,
      venue: row.venue ?? null,
      address: row.address ?? null,
      mapUrl: row.map_url ?? null,
      message: row.message ?? null,
    };
  });

const rsvpSchema = z.object({
  slug: z.string().min(1).max(80),
  guestName: z.string().trim().min(2).max(100),
  attending: z.boolean(),
  guestCount: z.number().int().min(0).max(20),
  message: z.string().max(500),
});

export const submitRsvp = createServerFn({ method: "POST" })
  .inputValidator((input: z.input<typeof rsvpSchema>) => rsvpSchema.parse(input))
  .handler(async ({ data }) => {
    const { error } = await publicClient().rpc("submit_rsvp", {
      _slug: data.slug,
      _guest_name: data.guestName,
      _attending: data.attending,
      _guest_count: data.attending ? Math.max(1, data.guestCount) : 0,
      _message: data.message,
    });
    if (error) {
      console.error("submit_rsvp failed", error);
      throw new Error("Չհաջողվեց պահպանել պատասխանը։ Փորձեք կրկին։");
    }
    return { ok: true };
  });

export type GuestRow = {
  guestName: string;
  attending: boolean;
  guestCount: number;
  message: string | null;
  createdAt: string;
};

export type GuestList = { title: string; eventDate: string; guests: GuestRow[] };

export const getEventGuests = createServerFn({ method: "GET" })
  .inputValidator((input: { slug: string; key: string }) =>
    z.object({ slug: z.string().min(1).max(80), key: z.string().max(64) }).parse(input),
  )
  .handler(async ({ data }): Promise<GuestList | null> => {
    if (!z.string().uuid().safeParse(data.key).success) return null;
    const { data: rows, error } = await publicClient().rpc("get_event_guests", {
      _slug: data.slug,
      _token: data.key,
    });
    if (error) {
      console.error("get_event_guests failed", error);
      throw new Error("Ցանկը հնարավոր չեղավ բեռնել");
    }
    const first = rows?.[0];
    if (!first) return null;
    return {
      title: first.title,
      eventDate: first.event_date,
      guests: (rows ?? [])
        .filter((r) => r.guest_name)
        .map((r) => ({
          guestName: r.guest_name,
          attending: r.attending,
          guestCount: r.guest_count,
          message: r.message ?? null,
          createdAt: r.created_at,
        })),
    };
  });
