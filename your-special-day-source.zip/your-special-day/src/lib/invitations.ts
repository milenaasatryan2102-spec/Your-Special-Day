// Client-safe helpers for real invitations (events) and guest answers.

const MONTHS = [
  "հունվարի", "փետրվարի", "մարտի", "ապրիլի", "մայիսի", "հունիսի",
  "հուլիսի", "օգոստոսի", "սեպտեմբերի", "հոկտեմբերի", "նոյեմբերի", "դեկտեմբերի",
];

const YEREVAN_OFFSET_MS = 4 * 60 * 60 * 1000; // Armenia is UTC+4 all year

function pad(n: number) {
  return String(n).padStart(2, "0");
}

/** "20 սեպտեմբերի 2027, 16:00" in Yerevan time, identical on server and browser. */
export function formatYerevanDate(iso: string): string {
  const d = new Date(new Date(iso).getTime() + YEREVAN_OFFSET_MS);
  const month = MONTHS[d.getUTCMonth()] ?? "";
  return `${d.getUTCDate()} ${month} ${d.getUTCFullYear()}, ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
}

/** Turns a date-time picked in the form ("2027-09-20T16:00") into Yerevan time. */
export function yerevanLocalToIso(local: string): string {
  return new Date(`${local}:00+04:00`).toISOString();
}

export type GuestAnswer = { attending: boolean; guest_count: number };

export function summarizeGuests(answers: GuestAnswer[]) {
  const coming = answers.filter((a) => a.attending);
  return {
    answers: answers.length,
    comingAnswers: coming.length,
    notComingAnswers: answers.length - coming.length,
    totalGuests: coming.reduce((sum, a) => sum + a.guest_count, 0),
  };
}

export const eventTypeLabels: Record<string, string> = {
  wedding: "Հարսանիք",
  engagement: "Նշանադրություն",
  baptism: "Կնունք",
  birthday: "Ծնունդ",
};

export function randomSlug(): string {
  const chars = "abcdefghjkmnpqrstuvwxyz23456789";
  let out = "";
  for (let i = 0; i < 7; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

export function isValidSlug(slug: string): boolean {
  return /^[a-z0-9](?:[a-z0-9-]{1,48}[a-z0-9])$/.test(slug);
}
