import ivoryVows from "@/assets/templates/ivory-vows.webp";
import goldenHour from "@/assets/templates/golden-hour.webp";
import blushGarden from "@/assets/templates/blush-garden.webp";
import olivePromise from "@/assets/templates/olive-promise.webp";
import holyLight from "@/assets/templates/holy-light.webp";
import littleAngel from "@/assets/templates/little-angel.webp";
import sweetBloom from "@/assets/templates/sweet-bloom.webp";
import starNight from "@/assets/templates/star-night.webp";

export const INSTAGRAM_HANDLE = "your_specialday.studio";
export const INSTAGRAM_URL = `https://www.instagram.com/${INSTAGRAM_HANDLE}/`;
export const DIRECT_URL = `https://ig.me/m/${INSTAGRAM_HANDLE}`;

export const PRICES = {
  standard: 8900,
  animated: 11900,
} as const;

export type CategoryId = "wedding" | "engagement" | "baptism" | "birthday";

export type Category = {
  id: CategoryId;
  label: string;
  description: string;
  cover: string;
};

export const categories: Category[] = [
  {
    id: "wedding",
    label: "Հարսանիք",
    description: "Նրբագեղ հրավիրատոմսեր ձեր ամենակարևոր օրվա համար",
    cover: ivoryVows,
  },
  {
    id: "engagement",
    label: "Նշանադրություն",
    description: "Սիրո խոստման առաջին գեղեցիկ քայլը",
    cover: olivePromise,
  },
  {
    id: "baptism",
    label: "Կնունք",
    description: "Լուսավոր և քնքուշ դիզայններ փոքրիկների համար",
    cover: holyLight,
  },
  {
    id: "birthday",
    label: "Ծնունդ",
    description: "Առաջին տարեդարձից մինչև շքեղ երեկույթ",
    cover: sweetBloom,
  },
];

export type Template = {
  slug: string;
  code: string;
  name: string;
  category: CategoryId;
  animated: boolean;
  isNew: boolean;
  image: string;
  tagline: string;
};

export const templates: Template[] = [
  {
    slug: "blush-garden",
    code: "YSD-108",
    name: "Blush Garden",
    category: "wedding",
    animated: true,
    isNew: true,
    image: blushGarden,
    tagline: "Վարդագույն վարդերի կամար և ռոմանտիկ կալիգրաֆիա",
  },
  {
    slug: "star-night",
    code: "YSD-107",
    name: "Star Night",
    category: "birthday",
    animated: true,
    isNew: true,
    image: starNight,
    tagline: "Սև և ոսկեգույն շքեղություն՝ երեկոյան խնջույքի համար",
  },
  {
    slug: "olive-promise",
    code: "YSD-106",
    name: "Olive Promise",
    category: "engagement",
    animated: false,
    isNew: true,
    image: olivePromise,
    tagline: "Ձիթենու ճյուղեր, ոսկե մատանիներ և մաքուր մինիմալիզմ",
  },
  {
    slug: "golden-hour",
    code: "YSD-105",
    name: "Golden Hour",
    category: "wedding",
    animated: true,
    isNew: false,
    image: goldenHour,
    tagline: "Մայրամուտի ոսկե լույս և art deco զարդանախշեր",
  },
  {
    slug: "holy-light",
    code: "YSD-104",
    name: "Holy Light",
    category: "baptism",
    animated: true,
    isNew: false,
    image: holyLight,
    tagline: "Երկնային լույս, աղավնի և սպիտակ շուշաններ",
  },
  {
    slug: "ivory-vows",
    code: "YSD-103",
    name: "Ivory Vows",
    category: "wedding",
    animated: false,
    isNew: false,
    image: ivoryVows,
    tagline: "Սպիտակ քաջվարդեր և ոսկեգույն նուրբ շրջանակ",
  },
  {
    slug: "little-angel",
    code: "YSD-102",
    name: "Little Angel",
    category: "baptism",
    animated: false,
    isNew: false,
    image: littleAngel,
    tagline: "Հրեշտակի թևեր և քնքուշ վարդագույն ծաղիկներ",
  },
  {
    slug: "sweet-bloom",
    code: "YSD-101",
    name: "Sweet Bloom",
    category: "birthday",
    animated: false,
    isNew: false,
    image: sweetBloom,
    tagline: "Փափուկ արջուկ, փուչիկներ և ոսկեգույն «1»",
  },
];

export const baseFeatures = [
  "Ձեր անունները, ամսաթիվը և տեքստը",
  "Եկեղեցու և սրահի հասցեն՝ քարտեզի հղումով",
  "Հետհաշվարկ մինչև միջոցառումը",
  "Հյուրերի հաստատում (RSVP)",
  "Մեկ հղում՝ ուղարկելու բոլոր հյուրերին",
];

export const animatedFeatures = ["Անիմացիոն էֆեկտներ", "Ֆոնային երաժշտություն"];

export function isCategoryId(value: unknown): value is CategoryId {
  return categories.some((c) => c.id === value);
}

export function getCategory(id: CategoryId): Category {
  const found = categories.find((c) => c.id === id);
  if (!found) throw new Error(`Unknown category ${id}`);
  return found;
}

export function getTemplate(slug: string): Template | undefined {
  return templates.find((t) => t.slug === slug);
}

export function priceOf(template: Pick<Template, "animated">): number {
  return template.animated ? PRICES.animated : PRICES.standard;
}

export function featuresOf(template: Pick<Template, "animated">): string[] {
  return template.animated ? [...baseFeatures, ...animatedFeatures] : baseFeatures;
}

export function formatPrice(amount: number): string {
  return `${String(amount).replace(/\B(?=(\d{3})+(?!\d))/g, " ")} ֏`;
}

export type CatalogFilter = { category?: CategoryId; animated?: boolean };

export function filterTemplates(list: Template[], filter: CatalogFilter): Template[] {
  return list.filter(
    (t) =>
      (filter.category === undefined || t.category === filter.category) &&
      (filter.animated !== true || t.animated),
  );
}

export function countByCategory(id: CategoryId): number {
  return templates.filter((t) => t.category === id).length;
}
