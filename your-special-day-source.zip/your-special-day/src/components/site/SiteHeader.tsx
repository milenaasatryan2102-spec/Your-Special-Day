import { Link } from "@tanstack/react-router";
import { Menu, Send, X } from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { DIRECT_URL } from "@/lib/catalog";
import { Logo } from "./Logo";

const nav = [
  { to: "/", label: "Գլխավոր" },
  { to: "/catalog", label: "Կատալոգ" },
  { to: "/how-to-order", label: "Ինչպես պատվիրել" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur-md">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 md:px-8">
        <Logo />
        <nav className="hidden items-center gap-9 md:flex">
          {nav.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.to === "/" }}
              className="text-sm tracking-wide text-muted-foreground transition-colors hover:text-foreground data-[status=active]:text-foreground"
              activeProps={{ className: "font-medium" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="hidden md:block">
          <Button asChild variant="gold">
            <a href={DIRECT_URL} target="_blank" rel="noreferrer">
              <Send /> Պատվիրել Direct-ով
            </a>
          </Button>
        </div>
        <button
          type="button"
          className="grid size-10 place-items-center rounded-full border border-border md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Մենյու"
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>
      {open && (
        <div className="border-t border-border/60 bg-background md:hidden">
          <nav className="mx-auto flex max-w-7xl flex-col gap-1 px-5 py-4">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-3 text-base text-foreground hover:bg-secondary"
              >
                {item.label}
              </Link>
            ))}
            <Button asChild variant="gold" className="mt-2">
              <a href={DIRECT_URL} target="_blank" rel="noreferrer">
                <Send /> Պատվիրել Direct-ով
              </a>
            </Button>
          </nav>
        </div>
      )}
    </header>
  );
}
