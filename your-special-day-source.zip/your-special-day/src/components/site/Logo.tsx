import { Link } from "@tanstack/react-router";

import logo from "@/assets/logo.webp";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="group flex items-center gap-3" aria-label="Your Special Day — գլխավոր">
      <img src={logo} alt="" width={48} height={48} className="size-12 rounded-full shadow-soft" />
      {!compact && (
        <span className="flex flex-col leading-none">
          <span className="font-script text-2xl text-foreground">Your Special Day</span>
          <span className="mt-1 text-[0.6rem] uppercase tracking-[0.3em] text-muted-foreground">
            Digital invitations studio
          </span>
        </span>
      )}
    </Link>
  );
}
