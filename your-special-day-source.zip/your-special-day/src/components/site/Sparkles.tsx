const points = [
  { top: "8%", left: "14%", delay: "0s", size: 6 },
  { top: "18%", left: "82%", delay: "0.6s", size: 4 },
  { top: "34%", left: "8%", delay: "1.2s", size: 5 },
  { top: "46%", left: "90%", delay: "0.3s", size: 7 },
  { top: "62%", left: "20%", delay: "1.8s", size: 4 },
  { top: "74%", left: "76%", delay: "0.9s", size: 6 },
  { top: "86%", left: "40%", delay: "1.5s", size: 5 },
  { top: "26%", left: "52%", delay: "2.1s", size: 3 },
];

/** Decorative twinkling dots used to hint that an invitation is animated. */
export function Sparkles() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0">
      {points.map((p, i) => (
        <span
          key={i}
          className="absolute animate-twinkle rounded-full bg-gold-soft shadow-glow"
          style={{ top: p.top, left: p.left, width: p.size, height: p.size, animationDelay: p.delay }}
        />
      ))}
    </div>
  );
}
