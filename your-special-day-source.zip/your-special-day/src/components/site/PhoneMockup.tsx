import { cn } from "@/lib/utils";
import { Sparkles } from "./Sparkles";

export function PhoneMockup({
  image,
  alt,
  animated,
  className,
}: {
  image: string;
  alt: string;
  animated: boolean;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "relative mx-auto aspect-[9/18.5] w-full max-w-[320px] rounded-[2.75rem] bg-ink p-2.5 shadow-card",
        className,
      )}
    >
      <div className="absolute left-1/2 top-4 z-10 h-5 w-24 -translate-x-1/2 rounded-full bg-ink" />
      <div className="relative h-full w-full overflow-hidden rounded-[2.2rem] bg-muted">
        <img
          src={image}
          alt={alt}
          className={cn("h-full w-full object-cover", animated && "animate-ken-burns")}
        />
        {animated && <Sparkles />}
      </div>
    </div>
  );
}
