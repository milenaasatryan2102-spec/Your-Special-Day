import { Link } from "@tanstack/react-router";

import { DIRECT_URL, INSTAGRAM_HANDLE, INSTAGRAM_URL } from "@/lib/catalog";
import { Logo } from "./Logo";

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-secondary/50">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-3 md:px-8">
        <div className="space-y-4">
          <Logo />
          <p className="max-w-xs text-sm leading-relaxed text-muted-foreground">
            Թվային և անիմացիոն հրավիրատոմսեր հարսանիքի, նշանադրության, կնունքի և ծնունդի համար։
          </p>
        </div>
        <div>
          <h4 className="eyebrow mb-4">Բաժիններ</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/catalog" className="hover:text-primary">Կատալոգ</Link></li>
            <li><Link to="/how-to-order" className="hover:text-primary">Ինչպես պատվիրել</Link></li>
            <li><Link to="/admin" className="text-muted-foreground hover:text-primary">Ստուդիայի մուտք</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="eyebrow mb-4">Կապ</h4>
          <ul className="space-y-2 text-sm">
            <li>
              <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer" className="hover:text-primary">
                Instagram՝ @{INSTAGRAM_HANDLE}
              </a>
            </li>
            <li>
              <a href={DIRECT_URL} target="_blank" rel="noreferrer" className="hover:text-primary">
                Պատվերներ՝ Direct
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/70 py-5 text-center text-xs tracking-wide text-muted-foreground">
        © {new Date().getFullYear()} Your Special Day · Celebrate life's special moments
      </div>
    </footer>
  );
}
