import { Link } from "@tanstack/react-router";
import { Sparkles as SparklesIcon } from "lucide-react";

import { Button } from "@/components/ui/button";
import { DIRECT_URL, formatPrice, getCategory, priceOf, type Template } from "@/lib/catalog";
import { Sparkles } from "./Sparkles";

export function TemplateCard({ template }: { template: Template }) {
  const category = getCategory(template.category);

  return (
    <article className="group flex flex-col overflow-hidden rounded-3xl border border-border bg-card shadow-soft transition-shadow duration-500 hover:shadow-card">
      <Link
        to="/catalog/$slug"
        params={{ slug: template.slug }}
        className="relative block aspect-[3/4] overflow-hidden bg-muted"
      >
        <img
          src={template.image}
          alt={`${template.name} հրավիրատոմս`}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-[1.6s] ease-out group-hover:scale-105"
        />
        {template.animated && <Sparkles />}
        <div className="absolute left-3 top-3 flex flex-wrap gap-2">
          {template.isNew && (
            <span className="rounded-full bg-ink px-3 py-1 text-[0.65rem] font-medium uppercase tracking-[0.2em] text-ink-foreground">
              New
            </span>
          )}
          {template.animated && (
            <span className="inline-flex items-center gap-1 rounded-full bg-card/90 px-3 py-1 text-[0.7rem] text-foreground backdrop-blur">
              <SparklesIcon className="size-3 text-primary" /> Անիմացիոն
            </span>
          )}
        </div>
      </Link>
      <div className="flex flex-1 flex-col gap-3 p-5">
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span className="tracking-[0.2em]">{template.code}</span>
          <span>{category.label}</span>
        </div>
        <h3 className="text-2xl font-medium leading-tight">{template.name}</h3>
        <p className="text-lg font-medium text-primary">{formatPrice(priceOf(template))}</p>
        <div className="mt-auto grid grid-cols-2 gap-2 pt-2">
          <Button asChild variant="champagne">
            <Link to="/catalog/$slug" params={{ slug: template.slug }}>
              Դիտել
            </Link>
          </Button>
          <Button asChild variant="gold">
            <a href={DIRECT_URL} target="_blank" rel="noreferrer">
              Պատվիրել
            </a>
          </Button>
        </div>
      </div>
    </article>
  );
}
