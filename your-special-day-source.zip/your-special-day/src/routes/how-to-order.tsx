import { createFileRoute, Link } from "@tanstack/react-router";
import { Send } from "lucide-react";

import { SectionHeading } from "@/components/site/SectionHeading";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { DIRECT_URL, formatPrice, PRICES } from "@/lib/catalog";

export const Route = createFileRoute("/how-to-order")({
  head: () => ({
    meta: [
      { title: "Ինչպես պատվիրել — Your Special Day" },
      { name: "description", content: "Ինչպես պատվիրել թվային հրավիրատոմս Your Special Day-ից՝ քայլ առ քայլ, գներ և հաճախ տրվող հարցեր։" },
      { property: "og:title", content: "Ինչպես պատվիրել հրավիրատոմս — Your Special Day" },
      { property: "og:description", content: "Ընտրեք դիզայնը, գրեք մեզ Direct և ստացեք պատրաստի հղումը։" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: HowToOrder,
});

const steps = [
  { title: "Ընտրեք դիզայնը", text: "Կատալոգում գտեք ձեր սիրելի հրավիրատոմսը և հիշեք դրա կոդը (օր.՝ YSD-108)։" },
  { title: "Գրեք մեզ Instagram Direct", text: "Ուղարկեք դիզայնի կոդը և ձեր միջոցառման տվյալները։" },
  { title: "Ստացեք նախադիտումը", text: "Մենք կպատրաստենք հրավիրատոմսը և կուղարկենք ստուգելու։" },
  { title: "Կիսվեք հյուրերի հետ", text: "Ուղարկեք հղումը, իսկ հյուրերի պատասխանները տեսեք ձեր անձնական էջում։" },
];

const needed = [
  "Անունները (զույգի, երեխայի կամ ծննդյան հերոսի)",
  "Ամսաթիվը և ժամը",
  "Եկեղեցու և սրահի անունը, հասցեն",
  "Ցանկալի տեքստը կամ մաղթանքը",
  "Երաժշտությունը (անիմացիոն տարբերակի համար)",
];

const faq = [
  {
    q: "Ինչպե՞ս են հյուրերը պատասխանում",
    a: "Հրավիրատոմսում կա ձև, որտեղ հյուրը նշում է՝ կգա՞ թե ոչ, քանի հոգով և կարող է թողնել մաղթանք։ Դուք ստանում եք անձնական հղում, որտեղ տեսնում եք բոլոր պատասխանները և ընդհանուր թիվը։",
  },
  { q: "Որքա՞ն ժամանակում է պատրաստվում", a: "Սովորաբար 1–2 օրվա ընթացքում՝ տվյալները ստանալուց հետո։" },
  { q: "Կարո՞ղ եմ փոփոխություններ անել", a: "Այո, նախադիտումից հետո կարող եք խնդրել տեքստի և մանրամասների փոփոխություններ։" },
  { q: "Ինչպե՞ս ուղարկել հյուրերին", a: "Ստանում եք մեկ հղում, որը կարող եք ուղարկել Viber-ով, WhatsApp-ով, Instagram-ով կամ SMS-ով։" },
];

function HowToOrder() {
  return (
    <div className="bg-champagne">
      <section className="mx-auto max-w-7xl px-5 py-20 md:px-8">
        <SectionHeading eyebrow="Պատվեր" title="Ինչպես պատվիրել" text="Ամբողջ գործընթացը տեղի է ունենում Instagram Direct-ով՝ արագ և հեշտ։" />
        <ol className="mt-14 grid gap-6 md:grid-cols-4">
          {steps.map((s, i) => (
            <li key={s.title} className="rounded-3xl border border-border bg-card p-7 shadow-soft">
              <span className="font-display text-5xl italic text-gold-gradient">0{i + 1}</span>
              <h3 className="mt-3 text-2xl font-medium">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.text}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="mx-auto grid max-w-7xl gap-8 px-5 pb-20 md:grid-cols-2 md:px-8">
        <div className="rounded-3xl bg-ink p-9 text-ink-foreground">
          <h2 className="text-3xl font-medium">Ինչ ուղարկել մեզ</h2>
          <ul className="mt-6 space-y-3 text-ink-foreground/85">
            {needed.map((n) => (
              <li key={n} className="flex gap-3">
                <span className="mt-2 size-1.5 shrink-0 rounded-full bg-gold-soft" />
                {n}
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-3xl border border-border bg-card p-9">
          <h2 className="text-3xl font-medium">Գներ</h2>
          <div className="mt-6 divide-y divide-border">
            <div className="flex items-center justify-between py-4">
              <span>Սովորական հրավիրատոմս</span>
              <span className="font-display text-2xl text-primary">{formatPrice(PRICES.standard)}</span>
            </div>
            <div className="flex items-center justify-between py-4">
              <span>Անիմացիոն հրավիրատոմս</span>
              <span className="font-display text-2xl text-primary">{formatPrice(PRICES.animated)}</span>
            </div>
          </div>
          <p className="mt-4 text-sm text-muted-foreground">Երկուսն էլ ներառում են հյուրերի օնլայն պատասխանը և ձեր անձնական ցանկի էջը։</p>
          <Button asChild variant="champagne" className="mt-6">
            <Link to="/catalog">Ընտրել դիզայնը</Link>
          </Button>
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-5 pb-24 md:px-8">
        <h2 className="text-center text-4xl font-medium">Հաճախ տրվող հարցեր</h2>
        <Accordion type="single" collapsible className="mt-10">
          {faq.map((f) => (
            <AccordionItem key={f.q} value={f.q}>
              <AccordionTrigger className="text-left text-lg">{f.q}</AccordionTrigger>
              <AccordionContent className="text-muted-foreground">{f.a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
        <div className="mt-12 text-center">
          <Button asChild variant="gold" size="xl">
            <a href={DIRECT_URL} target="_blank" rel="noreferrer">
              <Send /> Գրել Direct
            </a>
          </Button>
        </div>
      </section>
    </div>
  );
}
