import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";

import { TemplateCard } from "@/components/site/TemplateCard";
import { cn } from "@/lib/utils";
import { categories, filterTemplates, formatPrice, isCategoryId, PRICES, templates, type CatalogFilter, type CategoryId } from "@/lib/catalog";

export const Route = createFileRoute("/catalog/")({
  validateSearch: (search: Record<string, unknown>): CatalogFilter => {
    const out: CatalogFilter = {};
    const category = search["category"];
    if (isCategoryId(category)) out.category = category;
    if (search["animated"] === true || search["animated"] === "true") out.animated = true;
    return out;
  },
  head: () => ({
    meta: [
      { title: "Կատալոգ — Your Special Day հրավիրատոմսեր" },
      { name: "description", content: "Հարսանյաց, կնունքի, ծնունդի և նշանադրության թվային հրավիրատոմսերի կատալոգ՝ գներով։" },
      { property: "og:title", content: "Հրավիրատոմսերի կատալոգ — Your Special Day" },
      { property: "og:description", content: "Ընտրեք կատեգորիան և ձեր սիրելի դիզայնը։" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CatalogPage,
});

function buildSearch(category: CategoryId | undefined, animated: boolean | undefined): CatalogFilter {
  const out: CatalogFilter = {};
  if (category) out.category = category;
  if (animated) out.animated = true;
  return out;
}

function Chip({ active, children }: { active: boolean; children: React.ReactNode }) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full border px-5 py-2.5 text-sm transition-colors",
        active ? "border-transparent bg-ink text-ink-foreground" : "border-border bg-card hover:bg-secondary",
      )}
    >
      {children}
    </span>
  );
}

function CatalogPage() {
  const search = Route.useSearch();
  const list = filterTemplates(templates, search);
  const active = search.category ? categories.find((c) => c.id === search.category) : undefined;

  return (
    <div className="bg-champagne">
      <section className="mx-auto max-w-7xl px-5 pb-10 pt-16 text-center md:px-8">
        <p className="eyebrow">Կատալոգ</p>
        <h1 className="mt-3 text-4xl font-medium sm:text-5xl md:text-6xl">{active ? active.label : "Ընտրեք հրավիրատոմս"}</h1>
        <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
          Բացեք ցանկացած դիզայն՝ տեսնելու մանրամասները։ Սովորական՝ {formatPrice(PRICES.standard)}, անիմացիոն՝{" "}
          {formatPrice(PRICES.animated)}։
        </p>
      </section>

      <div className="sticky top-20 z-30 border-y border-border/60 bg-background/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-5 py-4 md:justify-center md:px-8">
          <Link to="/catalog" className="shrink-0" search={buildSearch(undefined, search.animated)}>
            <Chip active={!search.category}>Բոլորը</Chip>
          </Link>
          {categories.map((c) => (
            <Link key={c.id} to="/catalog" className="shrink-0" search={buildSearch(c.id, search.animated)}>
              <Chip active={search.category === c.id}>{c.label}</Chip>
            </Link>
          ))}
          <span className="mx-1 w-px shrink-0 bg-border" />
          <Link to="/catalog" className="shrink-0" search={buildSearch(search.category, !search.animated)}>
            <Chip active={search.animated === true}>
              <Sparkles className="size-4" /> Անիմացիոն
            </Chip>
          </Link>
        </div>
      </div>

      <section className="mx-auto max-w-7xl px-5 py-12 md:px-8">
        <p className="mb-6 text-sm text-muted-foreground">Գտնվել է՝ {list.length}</p>
        {list.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-border bg-card p-16 text-center text-muted-foreground">
            Այս ընտրությամբ դիզայններ դեռ չկան։{" "}
            <Link to="/catalog" className="text-primary underline">
              Տեսնել բոլորը
            </Link>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {list.map((t) => (
              <TemplateCard key={t.slug} template={t} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
