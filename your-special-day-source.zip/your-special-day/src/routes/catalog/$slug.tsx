import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, Check, Send, Sparkles } from "lucide-react";

import { PhoneMockup } from "@/components/site/PhoneMockup";
import { TemplateCard } from "@/components/site/TemplateCard";
import { Button } from "@/components/ui/button";
import { DIRECT_URL, featuresOf, formatPrice, getCategory, getTemplate, priceOf, templates } from "@/lib/catalog";

export const Route = createFileRoute("/catalog/$slug")({
  loader: ({ params }) => {
    const template = getTemplate(params.slug);
    if (!template) throw notFound();
    return { slug: template.slug, name: template.name, tagline: template.tagline };
  },
  head: ({ loaderData }) => {
    const title = loaderData ? `${loaderData.name} հրավիրատոմս — Your Special Day` : "Հրավիրատոմս — Your Special Day";
    const description = loaderData?.tagline ?? "Թվային հրավիրատոմս Your Special Day ստուդիայից։";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "product" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-xl px-5 py-32 text-center">
      <h1 className="text-4xl">Դիզայնը չի գտնվել</h1>
      <Button asChild variant="gold" className="mt-8">
        <Link to="/catalog">Վերադառնալ կատալոգ</Link>
      </Button>
    </div>
  ),
  component: TemplatePage,
});

function TemplatePage() {
  const { slug } = Route.useLoaderData();
  const template = getTemplate(slug);
  if (!template) return null;
  const category = getCategory(template.category);
  const related = templates.filter((t) => t.slug !== template.slug && t.category === template.category)
    .concat(templates.filter((t) => t.category !== template.category))
    .slice(0, 4);

  return (
    <div className="bg-champagne">
      <div className="mx-auto max-w-7xl px-5 pt-10 md:px-8">
        <Link to="/catalog" search={{ category: template.category }} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="size-4" /> {category.label}
        </Link>
      </div>
      <section className="mx-auto grid max-w-7xl items-center gap-14 px-5 py-12 md:grid-cols-2 md:px-8">
        <div className="relative">
          <div className="absolute inset-10 -z-10 rounded-full bg-gold-soft/40 blur-3xl" />
          <PhoneMockup image={template.image} alt={`${template.name} հրավիրատոմս`} animated={template.animated} className="animate-float" />
        </div>
        <div>
          <div className="flex flex-wrap items-center gap-3 text-xs uppercase tracking-[0.25em] text-muted-foreground">
            <span>{template.code}</span>
            <span>·</span>
            <span>{category.label}</span>
            {template.animated && (
              <span className="inline-flex items-center gap-1 rounded-full bg-card px-3 py-1 normal-case tracking-normal text-foreground">
                <Sparkles className="size-3 text-primary" /> Անիմացիոն
              </span>
            )}
          </div>
          <h1 className="mt-4 text-5xl font-medium md:text-6xl">{template.name}</h1>
          <p className="mt-4 text-lg text-muted-foreground">{template.tagline}</p>
          <p className="mt-8 font-display text-4xl text-primary">{formatPrice(priceOf(template))}</p>

          <ul className="mt-8 space-y-3">
            {featuresOf(template).map((f) => (
              <li key={f} className="flex items-start gap-3">
                <span className="mt-0.5 grid size-5 place-items-center rounded-full bg-gold-gradient text-primary-foreground">
                  <Check className="size-3" />
                </span>
                {f}
              </li>
            ))}
          </ul>

          <div className="mt-10 flex flex-wrap gap-3">
            <Button asChild variant="gold" size="xl">
              <a href={DIRECT_URL} target="_blank" rel="noreferrer">
                <Send /> Պատվիրել Direct-ով
              </a>
            </Button>
            <Button asChild variant="champagne" size="xl">
              <Link to="/i/$slug" params={{ slug: "demo" }}>
                Տեսնել կենդանի օրինակը
              </Link>
            </Button>
          </div>
          <p className="mt-5 text-sm text-muted-foreground">
            Գրեք մեզ դիզայնի կոդը՝ <b className="text-foreground">{template.code}</b>, և մենք կպատրաստենք այն ձեր
            տվյալներով։
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 pb-24 md:px-8">
        <h2 className="mb-8 text-3xl font-medium md:text-4xl">Նմանատիպ դիզայններ</h2>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {related.map((t) => (
            <TemplateCard key={t.slug} template={t} />
          ))}
        </div>
      </section>
    </div>
  );
}
