import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Heart, UserCheck, UserX, Users } from "lucide-react";

import { formatYerevanDate, summarizeGuests } from "@/lib/invitations";
import { getEventGuests } from "@/lib/invitations.functions";

const guestsQuery = (slug: string, key: string) =>
  queryOptions({ queryKey: ["event-guests", slug, key], queryFn: () => getEventGuests({ data: { slug, key } }) });

export const Route = createFileRoute("/i/$slug_/guests")({
  validateSearch: (search: Record<string, unknown>): { key: string } => ({
    key: typeof search["key"] === "string" ? search["key"] : "",
  }),
  loaderDeps: ({ search }) => ({ key: search.key }),
  loader: ({ context, params, deps }) => context.queryClient.ensureQueryData(guestsQuery(params.slug, deps.key)),
  head: () => ({
    meta: [
      { title: "Հյուրերի ցանկ — Your Special Day" },
      { name: "description", content: "Հյուրերի պատասխանների անձնական էջ։" },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Հյուրերի ցանկ — Your Special Day" },
      { property: "og:description", content: "Հյուրերի պատասխանների անձնական էջ։" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: GuestsPage,
});

function GuestsPage() {
  const { slug } = Route.useParams();
  const { key } = Route.useSearch();
  const { data } = useSuspenseQuery(guestsQuery(slug, key));

  if (!data) {
    return (
      <div className="grid min-h-screen place-items-center bg-champagne px-5 text-center">
        <div>
          <p className="font-script text-4xl text-primary">Your Special Day</p>
          <h1 className="mt-4 text-3xl">Հղումը սխալ է</h1>
          <p className="mt-2 text-muted-foreground">Օգտագործեք այն անձնական հղումը, որը ստացել եք ստուդիայից։</p>
        </div>
      </div>
    );
  }

  const summary = summarizeGuests(data.guests.map((g) => ({ attending: g.attending, guest_count: g.guestCount })));
  const stats = [
    { icon: Users, label: "Ընդհանուր հյուր", value: summary.totalGuests },
    { icon: UserCheck, label: "Կգան (պատասխան)", value: summary.comingAnswers },
    { icon: UserX, label: "Չեն կարող գալ", value: summary.notComingAnswers },
  ];

  return (
    <div className="min-h-screen bg-champagne">
      <div className="mx-auto max-w-5xl px-5 py-14 md:px-8">
        <p className="eyebrow">Հյուրերի ցանկ</p>
        <h1 className="mt-3 text-5xl font-medium">{data.title}</h1>
        <p className="mt-2 text-muted-foreground">{formatYerevanDate(data.eventDate)}</p>

        <div className="mt-10 grid gap-4 sm:grid-cols-3">
          {stats.map((s) => (
            <div key={s.label} className="rounded-3xl border border-border bg-card p-6 shadow-soft">
              <s.icon className="size-6 text-primary" />
              <p className="mt-4 font-display text-5xl">{s.value}</p>
              <p className="text-sm text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="mt-10 overflow-hidden rounded-3xl border border-border bg-card">
          {data.guests.length === 0 ? (
            <p className="p-12 text-center text-muted-foreground">Դեռ պատասխաններ չկան։ Ուղարկեք հրավիրատոմսի հղումը հյուրերին։</p>
          ) : (
            <ul className="divide-y divide-border">
              {data.guests.map((g, i) => (
                <li key={`${g.createdAt}-${i}`} className="flex flex-col gap-2 p-5 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <p className="text-lg font-medium">{g.guestName}</p>
                    {g.message && (
                      <p className="mt-1 flex items-start gap-2 text-sm text-muted-foreground">
                        <Heart className="mt-0.5 size-4 shrink-0 text-primary" /> {g.message}
                      </p>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    {g.attending ? (
                      <span className="rounded-full bg-gold-gradient px-4 py-1.5 text-primary-foreground">Կգա · {g.guestCount} հոգի</span>
                    ) : (
                      <span className="rounded-full bg-muted px-4 py-1.5 text-muted-foreground">Չի գա</span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
