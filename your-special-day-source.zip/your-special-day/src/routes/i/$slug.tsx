import { queryOptions, useMutation, useSuspenseQuery } from "@tanstack/react-query";
import { createFileRoute, notFound } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { CalendarDays, Heart, MapPin, Minus, Plus } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";

import { Sparkles } from "@/components/site/Sparkles";
import { Button } from "@/components/ui/button";
import { getTemplate } from "@/lib/catalog";
import { eventTypeLabels, formatYerevanDate } from "@/lib/invitations";
import { getPublicEvent, submitRsvp } from "@/lib/invitations.functions";
import { cn } from "@/lib/utils";

const eventQuery = (slug: string) =>
  queryOptions({ queryKey: ["public-event", slug], queryFn: () => getPublicEvent({ data: { slug } }) });

export const Route = createFileRoute("/i/$slug")({
  loader: async ({ context, params }) => {
    const event = await context.queryClient.ensureQueryData(eventQuery(params.slug));
    if (!event) throw notFound();
    return { title: event.title, eventType: event.eventType, date: event.eventDate };
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Հրավիրատոմս" }, { name: "robots", content: "noindex" }] };
    const title = `${loaderData.title} — հրավիրատոմս`;
    const description = `Սիրով հրավիրում ենք՝ ${formatYerevanDate(loaderData.date)}։ Խնդրում ենք հաստատել ձեր մասնակցությունը։`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { name: "robots", content: "noindex" },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  notFoundComponent: () => (
    <div className="grid min-h-screen place-items-center bg-champagne px-5 text-center">
      <div>
        <p className="font-script text-4xl text-primary">Your Special Day</p>
        <h1 className="mt-4 text-3xl">Հրավիրատոմսը չի գտնվել</h1>
        <p className="mt-2 text-muted-foreground">Ստուգեք հղումը կամ դիմեք հրավիրողին։</p>
      </div>
    </div>
  ),
  component: InvitationPage,
});

function Countdown({ date }: { date: string }) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    setNow(Date.now());
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const diff = now === null ? null : Math.max(0, new Date(date).getTime() - now);
  const parts = [
    { label: "օր", value: diff === null ? null : Math.floor(diff / 86400000) },
    { label: "ժամ", value: diff === null ? null : Math.floor((diff / 3600000) % 24) },
    { label: "րոպե", value: diff === null ? null : Math.floor((diff / 60000) % 60) },
    { label: "վրկ", value: diff === null ? null : Math.floor((diff / 1000) % 60) },
  ];
  return (
    <div className="grid grid-cols-4 gap-3">
      {parts.map((p) => (
        <div key={p.label} className="rounded-2xl border border-gold-soft bg-card/80 py-4 text-center">
          <div className="font-display text-3xl text-primary">{p.value ?? "–"}</div>
          <div className="text-xs text-muted-foreground">{p.label}</div>
        </div>
      ))}
    </div>
  );
}

function RsvpForm({ slug }: { slug: string }) {
  const send = useServerFn(submitRsvp);
  const [attending, setAttending] = useState<boolean | null>(null);
  const [count, setCount] = useState(1);
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [formError, setFormError] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: () =>
      send({ data: { slug, guestName: name, attending: attending === true, guestCount: attending ? count : 0, message } }),
  });

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (attending === null) {
      setFormError("Խնդրում ենք ընտրել՝ կգա՞ք, թե ոչ։");
      return;
    }
    if (name.trim().length < 2) {
      setFormError("Խնդրում ենք գրել ձեր անունը։");
      return;
    }
    setFormError(null);
    mutation.mutate();
  }

  if (mutation.isSuccess) {
    return (
      <div className="rounded-3xl border border-gold-soft bg-card p-10 text-center shadow-card">
        <Heart className="mx-auto size-10 text-primary" />
        <h3 className="mt-4 text-3xl font-medium">Շնորհակալություն, {name.trim()}</h3>
        <p className="mt-2 text-muted-foreground">
          {attending ? `Ձեր պատասխանը պահպանված է․ սպասում ենք ձեզ ${count} հոգով։` : "Ձեր պատասխանը պահպանված է։ Կկարոտենք ձեզ։"}
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="space-y-5 rounded-3xl border border-border bg-card p-7 shadow-card md:p-9">
      <div>
        <p className="mb-3 text-sm font-medium">Կմասնակցե՞ք</p>
        <div className="grid grid-cols-2 gap-3">
          {[
            { value: true, label: "Այո, կգամ" },
            { value: false, label: "Չեմ կարող գալ" },
          ].map((o) => (
            <button
              key={o.label}
              type="button"
              aria-pressed={attending === o.value}
              onClick={() => setAttending(o.value)}
              className={cn(
                "rounded-full border py-3.5 text-sm transition-all",
                attending === o.value ? "border-transparent bg-gold-gradient text-primary-foreground shadow-glow" : "border-border hover:bg-secondary",
              )}
            >
              {o.label}
            </button>
          ))}
        </div>
      </div>

      {attending && (
        <div className="flex items-center justify-between rounded-2xl bg-muted px-5 py-3">
          <span className="text-sm">Քանի՞ հոգով (ձեզ հետ միասին)</span>
          <div className="flex items-center gap-3">
            <button type="button" aria-label="Պակասեցնել" onClick={() => setCount((c) => Math.max(1, c - 1))} className="grid size-9 place-items-center rounded-full border border-border bg-card">
              <Minus className="size-4" />
            </button>
            <span className="w-6 text-center font-display text-2xl" aria-live="polite">{count}</span>
            <button type="button" aria-label="Ավելացնել" onClick={() => setCount((c) => Math.min(20, c + 1))} className="grid size-9 place-items-center rounded-full border border-border bg-card">
              <Plus className="size-4" />
            </button>
          </div>
        </div>
      )}

      <label className="block">
        <span className="mb-2 block text-sm font-medium">Անուն, ազգանուն</span>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={100}
          className="w-full rounded-2xl border border-input bg-background px-5 py-3.5 outline-none focus:ring-2 focus:ring-ring"
          placeholder="Օր.՝ Արամ և Անի Պետրոսյաններ"
        />
      </label>
      <label className="block">
        <span className="mb-2 block text-sm font-medium">Մաղթանք (ըստ ցանկության)</span>
        <textarea
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          maxLength={500}
          rows={3}
          className="w-full rounded-2xl border border-input bg-background px-5 py-3.5 outline-none focus:ring-2 focus:ring-ring"
        />
      </label>
      {(formError || mutation.error) && (
        <p className="text-sm text-destructive">{formError ?? mutation.error?.message}</p>
      )}
      <Button type="submit" variant="gold" size="xl" className="w-full" disabled={mutation.isPending}>
        {mutation.isPending ? "Ուղարկվում է…" : "Ուղարկել պատասխանը"}
      </Button>
    </form>
  );
}

function InvitationPage() {
  const { slug } = Route.useParams();
  const { data: event } = useSuspenseQuery(eventQuery(slug));
  if (!event) return null;
  const template = getTemplate(event.templateSlug);

  return (
    <div className="min-h-screen bg-champagne">
      <section className="relative mx-auto max-w-md px-5 pt-10">
        <div className="relative overflow-hidden rounded-[2.5rem] shadow-card">
          {template && <img src={template.image} alt={event.title} className={cn("aspect-[2/3] w-full object-cover", template.animated && "animate-ken-burns")} />}
          {template?.animated && <Sparkles />}
        </div>
      </section>

      <section className="mx-auto max-w-xl space-y-12 px-5 py-14 text-center">
        <div className="animate-fade-up">
          <p className="eyebrow">{eventTypeLabels[event.eventType] ?? "Հրավեր"}</p>
          <h1 className="mt-4 text-5xl font-medium md:text-6xl">{event.title}</h1>
          {event.message && <p className="mx-auto mt-6 max-w-md leading-relaxed text-muted-foreground">{event.message}</p>}
        </div>

        <div className="space-y-5">
          <p className="inline-flex items-center gap-2 text-lg">
            <CalendarDays className="size-5 text-primary" /> {formatYerevanDate(event.eventDate)}
          </p>
          <Countdown date={event.eventDate} />
        </div>

        {(event.venue || event.address) && (
          <div className="rounded-3xl border border-border bg-card p-7">
            <MapPin className="mx-auto size-6 text-primary" />
            {event.venue && <p className="mt-3 text-xl font-medium">{event.venue}</p>}
            {event.address && <p className="mt-1 text-muted-foreground">{event.address}</p>}
            {event.mapUrl && (
              <Button asChild variant="champagne" className="mt-5">
                <a href={event.mapUrl} target="_blank" rel="noreferrer">
                  Բացել քարտեզում
                </a>
              </Button>
            )}
          </div>
        )}

        <div className="text-left">
          <h2 className="mb-6 text-center text-4xl font-medium">Հաստատեք ձեր մասնակցությունը</h2>
          <RsvpForm slug={event.slug} />
        </div>

        <p className="font-script text-3xl text-primary">Your Special Day</p>
      </section>
    </div>
  );
}
