import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Copy, ExternalLink, LogOut, Trash2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { categories, templates } from "@/lib/catalog";
import { eventTypeLabels, formatYerevanDate, isValidSlug, randomSlug, summarizeGuests, yerevanLocalToIso } from "@/lib/invitations";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Կառավարում — Your Special Day" },
      { name: "description", content: "Հրավիրատոմսերի և հյուրերի պատասխանների կառավարում։" },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Կառավարում — Your Special Day" },
      { property: "og:description", content: "Հրավիրատոմսերի կառավարում։" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminPage,
});

const inputCls = "w-full rounded-2xl border border-input bg-background px-4 py-3 outline-none focus:ring-2 focus:ring-ring";

function copy(text: string) {
  navigator.clipboard.writeText(text).then(() => toast.success("Հղումը պատճենված է"));
}

function AdminPage() {
  const { user } = Route.useRouteContext();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const role = useQuery({
    queryKey: ["is-admin", user.id],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("has_role", { _user_id: user.id, _role: "admin" });
      if (error) throw error;
      return data === true;
    },
  });

  const events = useQuery({
    queryKey: ["admin-events"],
    enabled: role.data === true,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("events")
        .select("id, slug, title, event_type, template_slug, event_date, manage_token, rsvps(attending, guest_count)")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const [form, setForm] = useState({
    title: "",
    eventType: "wedding",
    templateSlug: templates[0]?.slug ?? "",
    date: "",
    venue: "",
    address: "",
    mapUrl: "",
    message: "",
    slug: randomSlug(),
  });
  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const create = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("events").insert({
        slug: form.slug,
        title: form.title.trim(),
        event_type: form.eventType,
        template_slug: form.templateSlug,
        event_date: yerevanLocalToIso(form.date),
        venue: form.venue.trim() || null,
        address: form.address.trim() || null,
        map_url: form.mapUrl.trim() || null,
        message: form.message.trim() || null,
        created_by: user.id,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Հրավիրատոմսը ստեղծված է");
      setForm((f) => ({ ...f, title: "", date: "", venue: "", address: "", mapUrl: "", message: "", slug: randomSlug() }));
      queryClient.invalidateQueries({ queryKey: ["admin-events"] });
    },
    onError: (e: { code?: string }) => toast.error(e.code === "23505" ? "Այս հղումն արդեն զբաղված է" : "Չհաջողվեց ստեղծել"),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("events").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-events"] }),
  });

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!isValidSlug(form.slug)) {
      toast.error("Հղումը՝ միայն լատինատառ փոքրատառեր, թվեր և «-»");
      return;
    }
    if (!form.title.trim() || !form.date) {
      toast.error("Լրացրեք անունները և ամսաթիվը");
      return;
    }
    create.mutate();
  }

  const origin = typeof window !== "undefined" ? window.location.origin : "";

  return (
    <div className="bg-champagne">
      <div className="mx-auto max-w-6xl px-5 py-12 md:px-8">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="eyebrow">Ստուդիա</p>
            <h1 className="mt-2 text-5xl font-medium">Հրավիրատոմսեր</h1>
          </div>
          <Button variant="champagne" onClick={signOut}>
            <LogOut /> Ելք
          </Button>
        </div>

        {role.isLoading && <p className="mt-10 text-muted-foreground">Բեռնվում է…</p>}
        {role.data === false && (
          <div className="mt-10 rounded-3xl border border-border bg-card p-10 text-center">
            <h2 className="text-2xl">Մուտքը սահմանափակված է</h2>
            <p className="mt-2 text-muted-foreground">Այս էջը հասանելի է միայն ստուդիայի ադմինիստրատորին։</p>
          </div>
        )}

        {role.data === true && (
          <div className="mt-10 grid gap-8 lg:grid-cols-[400px_1fr]">
            <form onSubmit={onSubmit} className="h-fit space-y-4 rounded-3xl border border-border bg-card p-7 shadow-soft">
              <h2 className="text-2xl font-medium">Նոր հրավիրատոմս</h2>
              <input className={inputCls} placeholder="Անուններ (օր.՝ Աննա & Դավիթ)" value={form.title} onChange={set("title")} required />
              <div className="grid grid-cols-2 gap-3">
                <select className={inputCls} value={form.eventType} onChange={set("eventType")}>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.label}</option>
                  ))}
                </select>
                <select className={inputCls} value={form.templateSlug} onChange={set("templateSlug")}>
                  {templates.map((t) => (
                    <option key={t.slug} value={t.slug}>{t.code} · {t.name}</option>
                  ))}
                </select>
              </div>
              <label className="block text-sm">
                <span className="mb-1 block text-muted-foreground">Ամսաթիվ և ժամ (Երևան)</span>
                <input type="datetime-local" className={inputCls} value={form.date} onChange={set("date")} required />
              </label>
              <input className={inputCls} placeholder="Վայր (եկեղեցի, սրահ)" value={form.venue} onChange={set("venue")} />
              <input className={inputCls} placeholder="Հասցե" value={form.address} onChange={set("address")} />
              <input className={inputCls} placeholder="Քարտեզի հղում (Google Maps)" value={form.mapUrl} onChange={set("mapUrl")} />
              <textarea className={inputCls} rows={3} placeholder="Հրավերի տեքստ" value={form.message} onChange={set("message")} />
              <label className="block text-sm">
                <span className="mb-1 block text-muted-foreground">Հղման վերջավորություն</span>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">/i/</span>
                  <input className={inputCls} value={form.slug} onChange={(e) => setForm((f) => ({ ...f, slug: e.target.value.toLowerCase() }))} />
                </div>
              </label>
              <Button type="submit" variant="gold" className="h-11 w-full" disabled={create.isPending}>
                Ստեղծել
              </Button>
            </form>

            <div className="space-y-4">
              {events.isLoading && <p className="text-muted-foreground">Բեռնվում է…</p>}
              {events.data?.length === 0 && <p className="rounded-3xl border border-dashed border-border bg-card p-10 text-center text-muted-foreground">Դեռ հրավիրատոմսեր չկան։</p>}
              {events.data?.map((ev) => {
                const s = summarizeGuests(ev.rsvps);
                const inviteUrl = `${origin}/i/${ev.slug}`;
                const guestsUrl = `${origin}/i/${ev.slug}/guests?key=${ev.manage_token}`;
                return (
                  <article key={ev.id} className="rounded-3xl border border-border bg-card p-6 shadow-soft">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">
                          {eventTypeLabels[ev.event_type] ?? ev.event_type} · {ev.template_slug}
                        </p>
                        <h3 className="mt-1 text-2xl font-medium">{ev.title}</h3>
                        <p className="text-sm text-muted-foreground">{formatYerevanDate(ev.event_date)}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-display text-3xl text-primary">{s.totalGuests}</p>
                        <p className="text-xs text-muted-foreground">հյուր · {s.answers} պատասխան</p>
                      </div>
                    </div>
                    <div className="mt-5 grid gap-2 sm:grid-cols-2">
                      <div className="flex gap-2">
                        <Button variant="champagne" size="sm" className="flex-1" onClick={() => copy(inviteUrl)}>
                          <Copy /> Հյուրերի հղում
                        </Button>
                        <Button asChild variant="ghost" size="sm" aria-label="Բացել հրավիրատոմսը">
                          <a href={inviteUrl} target="_blank" rel="noreferrer"><ExternalLink /></a>
                        </Button>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="champagne" size="sm" className="flex-1" onClick={() => copy(guestsUrl)}>
                          <Copy /> Զույգի ցանկի հղում
                        </Button>
                        <Button asChild variant="ghost" size="sm" aria-label="Բացել ցանկը">
                          <a href={guestsUrl} target="_blank" rel="noreferrer"><ExternalLink /></a>
                        </Button>
                      </div>
                    </div>
                    <button
                      type="button"
                      className="mt-4 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-destructive"
                      onClick={() => {
                        if (confirm("Ջնջե՞լ այս հրավիրատոմսը և բոլոր պատասխանները")) remove.mutate(ev.id);
                      }}
                    >
                      <Trash2 className="size-3" /> Ջնջել
                    </button>
                  </article>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
