import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, CalendarHeart, CheckCircle2, MapPin, Music, Send, Share2, Sparkles, Timer, Users } from "lucide-react";

import heroImage from "@/assets/hero.webp";
import { SectionHeading } from "@/components/site/SectionHeading";
import { TemplateCard } from "@/components/site/TemplateCard";
import { Button } from "@/components/ui/button";
import { categories, countByCategory, DIRECT_URL, formatPrice, PRICES, templates } from "@/lib/catalog";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Your Special Day — թվային և անիմացիոն հրավիրատոմսեր" },
      {
        name: "description",
        content:
          "Նրբագեղ թվային հրավիրատոմսեր հարսանիքի, նշանադրության, կնունքի և ծնունդի համար՝ հյուրերի օնլայն պատասխանով։",
      },
      { property: "og:title", content: "Your Special Day — թվային հրավիրատոմսեր" },
      {
        property: "og:description",
        content: "Ընտրեք ձեր հրավիրատոմսը, հյուրերը կպատասխանեն օնլայն՝ կգա՞ն և քանի հոգով։",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const features = [
  { icon: Users, title: "Հյուրերի օնլայն պատասխան", text: "Կգա՞ն, թե ոչ, քանի հոգով և մաղթանքներ" },
  { icon: MapPin, title: "Քարտեզ և հասցե", text: "Եկեղեցու և սրահի հասցեն՝ մեկ սեղմումով" },
  { icon: Timer, title: "Հետհաշվարկ", text: "Օրերն ու ժամերը մինչև ձեր հատուկ օրը" },
  { icon: Music, title: "Երաժշտություն", text: "Ձեր սիրելի երգը՝ անիմացիոն տարբերակում" },
  { icon: Sparkles, title: "Անիմացիա", text: "Կենդանի էֆեկտներ, որոնք հիացնում են" },
  { icon: Share2, title: "Մեկ հղում", text: "Ուղարկեք Viber-ով, WhatsApp-ով կամ Instagram-ով" },
];

const steps = [
  { n: "01", title: "Ընտրեք դիզայնը", text: "Նայեք կատալոգը և ընտրեք ձեր ոճին համապատասխան հրավիրատոմսը։" },
  { n: "02", title: "Գրեք մեզ Direct", text: "Ուղարկեք անունները, ամսաթիվը, վայրերը և ցանկությունները։" },
  { n: "03", title: "Ստացեք հղումը", text: "Կիսվեք հյուրերի հետ և հետևեք նրանց պատասխաններին օնլայն։" },
];

function Index() {
  const newTemplates = templates.filter((t) => t.isNew).concat(templates.filter((t) => !t.isNew)).slice(0, 4);

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <img src={heroImage} alt="Թվային հրավիրատոմս հեռախոսում" className="absolute inset-0 h-full w-full object-cover object-right" />
        <div className="absolute inset-0 bg-hero-fade" />
        <div className="relative mx-auto flex min-h-[640px] max-w-7xl items-center px-5 py-24 md:min-h-[720px] md:px-8">
          <div className="max-w-xl animate-fade-up">
            <p className="eyebrow">Digital invitations studio</p>
            <h1 className="mt-5 text-4xl font-medium leading-[1.05] sm:text-5xl md:text-7xl">
              Հրավիրատոմսեր ձեր <span className="italic text-gold-gradient">հատուկ օրվա</span> համար
            </h1>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-muted-foreground">
              Հարսանիք, կնունք, ծնունդ․ նրբագեղ և անիմացիոն թվային հրավիրատոմսեր, որոնց հյուրերը պատասխանում են
              օնլայն։
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Button asChild variant="gold" size="xl">
                <Link to="/catalog">
                  Դիտել կատալոգը <ArrowRight />
                </Link>
              </Button>
              <Button asChild variant="champagne" size="xl">
                <a href={DIRECT_URL} target="_blank" rel="noreferrer">
                  <Send /> Պատվիրել Direct-ով
                </a>
              </Button>
            </div>
            <p className="mt-8 text-sm text-muted-foreground">
              Սկսած <span className="font-medium text-foreground">{formatPrice(PRICES.standard)}</span>-ից
            </p>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-5 py-24 md:px-8">
        <SectionHeading eyebrow="Կատեգորիաներ" title="Ընտրեք ձեր առիթը" />
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((c) => (
            <Link
              key={c.id}
              to="/catalog"
              search={{ category: c.id }}
              className="group relative aspect-[3/4] overflow-hidden rounded-3xl shadow-soft"
            >
              <img src={c.cover} alt={c.label} loading="lazy" className="h-full w-full object-cover transition-transform duration-[1.6s] group-hover:scale-105" />
              <div className="absolute inset-x-3 bottom-3 rounded-2xl bg-card/90 p-5 backdrop-blur-md">
                <h3 className="text-2xl font-medium">{c.label}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{c.description}</p>
                <p className="mt-3 inline-flex items-center gap-1 text-sm text-primary">
                  {countByCategory(c.id)} դիզայն <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* New templates */}
      <section className="bg-champagne py-24">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <SectionHeading eyebrow="Նորույթներ" title="Նոր հրավիրատոմսեր" text="Թարմ դիզայններ, որոնք կարող ենք պատրաստել ձեր անուններով արդեն այսօր։" />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {newTemplates.map((t) => (
              <TemplateCard key={t.slug} template={t} />
            ))}
          </div>
          <div className="mt-12 text-center">
            <Button asChild variant="ink" size="xl">
              <Link to="/catalog">Ամբողջ կատալոգը</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* RSVP highlight */}
      <section className="mx-auto grid max-w-7xl items-center gap-14 px-5 py-24 md:grid-cols-2 md:px-8">
        <div>
          <p className="eyebrow">Հյուրերի պատասխան</p>
          <h2 className="mt-3 text-4xl font-medium md:text-5xl">Հյուրերը պատասխանում են հենց հրավիրատոմսում</h2>
          <p className="mt-5 leading-relaxed text-muted-foreground">
            Յուրաքանչյուր հյուր ընտրում է՝ կգա՞ թե ոչ, քանի հոգով և կարող է թողնել մաղթանք։ Դուք ստանում եք
            առանձին էջ, որտեղ տեսնում եք ամբողջ ցանկը և ընդհանուր թիվը։
          </p>
          <Button asChild variant="gold" size="xl" className="mt-8">
            <Link to="/i/$slug" params={{ slug: "demo" }}>
              Փորձել կենդանի օրինակը <ArrowRight />
            </Link>
          </Button>
        </div>
        <div className="relative">
          <div className="absolute -inset-6 -z-10 rounded-[3rem] bg-secondary" />
          <div className="space-y-4 rounded-3xl border border-border bg-card p-7 shadow-card">
            <p className="font-script text-4xl text-primary">Lilit & Gor</p>
            <p className="text-sm text-muted-foreground">Խնդրում ենք հաստատել ձեր մասնակցությունը</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center justify-center gap-2 rounded-full bg-gold-gradient py-3 text-sm text-primary-foreground">
                <CheckCircle2 className="size-4" /> Կգամ
              </div>
              <div className="flex items-center justify-center rounded-full border border-border py-3 text-sm">Չեմ կարող գալ</div>
            </div>
            <div className="flex items-center justify-between rounded-2xl bg-muted px-5 py-4 text-sm">
              <span>Քանի՞ հոգով</span>
              <span className="font-medium">2 հոգի</span>
            </div>
            <div className="rounded-2xl bg-muted px-5 py-4 text-sm text-muted-foreground">«Շնորհավորում ենք, սիրելինե՛ր…»</div>
            <div className="flex items-center gap-3 rounded-2xl border border-gold-soft px-5 py-4 text-sm">
              <CalendarHeart className="size-5 text-primary" />
              <span>
                Հաստատել են <b>48</b> հյուր
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-ink py-24 text-ink-foreground">
        <div className="mx-auto max-w-7xl px-5 md:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <p className="eyebrow">Ինչ է ներառված</p>
            <h2 className="mt-3 text-4xl font-medium md:text-5xl">Ամեն ինչ՝ մեկ հղումում</h2>
          </div>
          <div className="mt-14 grid gap-px overflow-hidden rounded-3xl bg-ink-foreground/10 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f) => (
              <div key={f.title} className="bg-ink p-8">
                <f.icon className="size-7 text-gold-soft" />
                <h3 className="mt-5 text-2xl font-medium">{f.title}</h3>
                <p className="mt-2 text-sm text-ink-foreground/70">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Steps */}
      <section className="mx-auto max-w-7xl px-5 py-24 md:px-8">
        <SectionHeading eyebrow="Ինչպես պատվիրել" title="Երեք պարզ քայլ" />
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {steps.map((s) => (
            <div key={s.n} className="rounded-3xl border border-border bg-card p-8 shadow-soft">
              <span className="font-display text-5xl italic text-gold-gradient">{s.n}</span>
              <h3 className="mt-4 text-2xl font-medium">{s.title}</h3>
              <p className="mt-2 text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="px-5 pb-24 md:px-8">
        <div className="mx-auto max-w-5xl rounded-[2.5rem] bg-gold-gradient px-8 py-16 text-center text-primary-foreground shadow-glow">
          <p className="font-script text-4xl">Celebrate life's special moments</p>
          <h2 className="mt-4 text-4xl font-medium md:text-5xl">Պատրա՞ստ եք ձեր հատուկ օրվան</h2>
          <p className="mx-auto mt-4 max-w-lg opacity-90">Գրեք մեզ Instagram Direct, և մենք կպատրաստենք ձեր հրավիրատոմսը։</p>
          <Button asChild variant="ink" size="xl" className="mt-8">
            <a href={DIRECT_URL} target="_blank" rel="noreferrer">
              <Send /> Գրել Direct
            </a>
          </Button>
        </div>
      </section>
    </>
  );
}
