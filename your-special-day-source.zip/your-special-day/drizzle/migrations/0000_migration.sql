-- Roles
create type public.app_role as enum ('admin', 'user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "Users read own roles" on public.user_roles
  for select to authenticated using (user_id = auth.uid());

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- The very first account becomes the studio admin
create or replace function public.assign_first_admin()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  end if;
  return new;
end;
$$;
create trigger on_auth_user_created_assign_admin
  after insert on auth.users for each row execute function public.assign_first_admin();

-- Invitations (events)
create table public.events (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  template_slug text not null,
  event_type text not null default 'wedding',
  title text not null,
  event_date timestamptz not null,
  venue text,
  address text,
  map_url text,
  message text,
  manage_token uuid not null default gen_random_uuid(),
  created_by uuid,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.events to authenticated;
grant all on public.events to service_role;
alter table public.events enable row level security;
create policy "Admins manage events" on public.events
  for all to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));

-- Guest answers
create table public.rsvps (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  guest_name text not null,
  attending boolean not null,
  guest_count integer not null default 1,
  message text,
  created_at timestamptz not null default now()
);
create index rsvps_event_id_idx on public.rsvps(event_id);
grant select, delete on public.rsvps to authenticated;
grant all on public.rsvps to service_role;
alter table public.rsvps enable row level security;
create policy "Admins read rsvps" on public.rsvps
  for select to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "Admins delete rsvps" on public.rsvps
  for delete to authenticated using (public.has_role(auth.uid(), 'admin'));

-- Public: read invitation details (never the manage token)
create or replace function public.get_public_event(_slug text)
returns table (
  slug text, template_slug text, event_type text, title text, event_date timestamptz,
  venue text, address text, map_url text, message text
)
language sql stable security definer set search_path = public as $$
  select e.slug, e.template_slug, e.event_type, e.title, e.event_date, e.venue, e.address, e.map_url, e.message
  from public.events e where e.slug = _slug
$$;

-- Public: guest submits an answer
create or replace function public.submit_rsvp(
  _slug text, _guest_name text, _attending boolean, _guest_count integer, _message text
) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  _event_id uuid;
  _id uuid;
  _name text := btrim(coalesce(_guest_name, ''));
  _msg text := nullif(btrim(coalesce(_message, '')), '');
  _count integer;
begin
  select id into _event_id from public.events where slug = _slug;
  if _event_id is null then raise exception 'Invitation not found'; end if;
  if length(_name) < 2 or length(_name) > 100 then raise exception 'Invalid name'; end if;
  if _msg is not null and length(_msg) > 500 then raise exception 'Message too long'; end if;
  if _attending then
    if _guest_count is null or _guest_count < 1 or _guest_count > 20 then raise exception 'Invalid guest count'; end if;
    _count := _guest_count;
  else
    _count := 0;
  end if;
  insert into public.rsvps (event_id, guest_name, attending, guest_count, message)
  values (_event_id, _name, _attending, _count, _msg) returning id into _id;
  return _id;
end;
$$;

-- Couple: read answers with their private link
create or replace function public.get_event_guests(_slug text, _token uuid)
returns table (
  title text, event_date timestamptz, guest_name text, attending boolean,
  guest_count integer, message text, created_at timestamptz
)
language sql stable security definer set search_path = public as $$
  select e.title, e.event_date, r.guest_name, r.attending, r.guest_count, r.message, r.created_at
  from public.events e
  left join public.rsvps r on r.event_id = e.id
  where e.slug = _slug and e.manage_token = _token
  order by r.created_at desc nulls last
$$;

revoke all on function public.get_public_event(text) from public;
revoke all on function public.submit_rsvp(text, text, boolean, integer, text) from public;
revoke all on function public.get_event_guests(text, uuid) from public;
grant execute on function public.get_public_event(text) to anon, authenticated;
grant execute on function public.submit_rsvp(text, text, boolean, integer, text) to anon, authenticated;
grant execute on function public.get_event_guests(text, uuid) to anon, authenticated;
grant execute on function public.has_role(uuid, public.app_role) to authenticated;

-- Demo invitation shown from the catalog
insert into public.events (slug, template_slug, event_type, title, event_date, venue, address, map_url, message)
values (
  'demo', 'blush-garden', 'wedding', 'Լիլիթ & Գոռ', '2027-09-20 16:00:00+04',
  'Սուրբ Աննա եկեղեցի · Ռեստորան «Վարդագույն այգի»', 'Երևան, Աբովյան փողոց 12',
  'https://maps.google.com/?q=Yerevan',
  'Սիրով հրավիրում ենք կիսելու մեր կյանքի ամենագեղեցիկ օրը։ Ձեր ներկայությունը մեզ համար մեծ ուրախություն կլինի։'
);